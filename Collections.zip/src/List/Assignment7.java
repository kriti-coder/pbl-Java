package List;

import java.util.Iterator;
import java.util.Vector;

public class Assignment7 {

	public static void main(String[] args) {
		Vector<Employee> list = new Vector<Employee>();
		
		list.add(new Employee(101, "Kriti", "xyz@gmail.com", "F", 20000));
		list.add(new Employee(102, "Akriti", "ABC@gmail.com", "F", 30000));
		
		Iterator<Employee> it = list.iterator();
		while (it.hasNext()) 
			it.next().GetEmployeeDetails();


	}

}
