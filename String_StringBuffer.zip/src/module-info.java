module StringBuffer {
}