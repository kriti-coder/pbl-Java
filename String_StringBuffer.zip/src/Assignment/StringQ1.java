package Assignment;

public class StringQ1 {
	
	public static void main(String[] args) {   // input by arguments
		if(args.length!=1)
		{
			System.out.println("Pass 1 string by command line");
			return;
		}
			String str = args[0];
			StringBuffer stb = new StringBuffer(str);
			stb = stb.reverse();
			String str2 = stb.toString();
			if(str.equals(str2)) {
				System.out.println("Palindrome");
			}
			
			else
				System.out.println("Not Palindrome");
		} 
		
	}
