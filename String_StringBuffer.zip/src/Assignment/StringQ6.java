package Assignment;

public class StringQ6 {
	
	public static void main(String[] args)
	{
		String a="hi";
		String b="hello";
		String op;
		if(a.length()<b.length()) op=a+b+a;
		else op=b+a+b;
		System.out.println(op);
		
	}
}
