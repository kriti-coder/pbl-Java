package packages.account;

public abstract class Account {
	
	double interestRate;
	double amount;
	
	public abstract double calculateInterest();

}
