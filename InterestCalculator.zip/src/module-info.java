module InterestCalculator {
}