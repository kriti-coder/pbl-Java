package assignment;

import java.util.Scanner;

public class Assignment2{
	public static void main(String args[]){

		String input1, output1;
		Scanner sc = new Scanner(System.in);
		input1 = sc.nextLine();
		output1 = "Welcome"+" "+input1;
		System.out.println(output1);
		sc.close();
}
}