package assignment;

import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) {
		long  input1,input2,sum;
		Scanner sc = new Scanner(System.in);
		input1 = sc.nextLong();
		input2 = sc.nextLong();
		sum = input1+input2;
		System.out.println(sum);
		sc.close();
	}

}