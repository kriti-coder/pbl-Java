package assignment;

import java.util.Scanner;

public class Assignment1 {

	public static void main(String[] args) {
		
		String input1,input2,s;
		Scanner sc = new Scanner(System.in);
		input1 = sc.nextLine();
		input2 = sc.nextLine();
		s = input1 + " "+"Technologies"+ " " + input2;
		System.out.println(s);
		sc.close();
	}

}
