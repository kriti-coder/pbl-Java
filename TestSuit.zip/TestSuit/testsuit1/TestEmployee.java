package testsuit1;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestEmployee {
	Testsuit obj=new Testsuit();
	ArrayList<String> names = new ArrayList<String>( Arrays.asList("shyam", "meet", "parth") );
	String name="kriti";

	@Test
	void test() {
		assertEquals("FOUND", obj.findName(names, name));
	}

}
