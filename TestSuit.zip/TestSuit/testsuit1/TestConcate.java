package testsuit1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestConcate {
	Testsuit obj=new Testsuit();

	@Test
	void test() {
		assertEquals("Kriti",obj.stringConcat("Kr","iti"));
	}

}
