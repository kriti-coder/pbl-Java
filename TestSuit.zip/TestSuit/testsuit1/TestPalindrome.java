package testsuit1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPalindrome {
	Testsuit obj=new Testsuit();

	@Test
	void test() {
		assertEquals(true, obj.palindromeCheck("DAD"));
	}

}
