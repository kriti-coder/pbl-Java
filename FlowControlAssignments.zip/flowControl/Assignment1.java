package flowControl;

import java.util.Scanner;

public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int input1;
		Scanner sc = new Scanner(System.in);
		input1 = sc.nextInt();
		if(input1==0)
			System.out.println("Number is Zero");
		else if(input1<0)
			System.out.println("Number is Negative");
		else
			System.out.println("Number is Positive");
		sc.close();

	}

}