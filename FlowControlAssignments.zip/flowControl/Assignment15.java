package flowControl;

import java.util.Scanner;

class Assignment15
{
	public static void main(String args[])	
	{
	    long n,sum;
             	    Scanner sc=new Scanner(System.in);
	    
                   n=Integer.parseInt(args[0]);
	    for(sum=0 ;n!=0 ;n/=10)
	    {
		sum+=n%10;
	    }
	    System.out.println(sum); 
	    sc.close();
	}
}