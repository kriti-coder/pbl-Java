package exception;

public class NullStudentException extends Exception {

	@Override
	public String toString() {
		return "NullStudentException occurred";
	}
	
}