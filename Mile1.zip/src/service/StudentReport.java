package service;

import bean.Student;
import exception.NullMarksArrayException;
import exception.NullNameException;
import exception.NullStudentException;

public class StudentReport {

	public String findGrade(Student studentObject) {
		
		int marks[]=studentObject.getMarks();
		
		int total=0;
		for(int i=0;i<marks.length;i++) {
			if(marks[i]<35) return "F";
			else total+=marks[i];
		}
		
		if(total<=150) return "D";
		else if(total<=200) return "C";
		else if(total<=250) return "B";
		else if(total<=300) return "A";
		
		return "D";
	}
	
	public String validate(Student studentObject) throws NullStudentException,NullNameException,NullMarksArrayException{
		if(studentObject==null)
			throw new NullStudentException();
		else {
			if(studentObject.getName()==null) throw new NullNameException();
			if(studentObject.getMarks()==null) throw new NullMarksArrayException();
			
			return findGrade(studentObject);
		}
	}
}