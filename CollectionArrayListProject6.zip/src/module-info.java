module collectionProject6 {
}