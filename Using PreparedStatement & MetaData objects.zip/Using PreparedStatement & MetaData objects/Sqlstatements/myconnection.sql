CREATE TABLE stdnt_log (
	Rollno Number (4) Primary Key,
	StudentName Varchar (20)  Not Null,
	Standard Varchar (2) Not Null,
	Date_Of_Birth Date,
	Fees Number (9,2)
);
CREATE TABLE stdnt (
	Rollno Number (4) Primary Key,
	StudentName Varchar (20)  Not Null,
	Standard Varchar (2) Not Null,
	Date_Of_Birth Date,
	Fees Number (9,2)
);


/*DESC STDNT;*/

select * from stdnt;

update stdnt set fees=? where rollno=?; 

INSERT INTO stdnt VALUES(1002, 'ALICE', 'V', '16-Aug-1947', 4300.0);

