package arrayAssignments;

import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) {
		
		int arr[]={1,4,34,56,7};
		int i, toSearchValue,index=0,search=-1;
		for(i=0;i<arr.length;i++)
		{
			System.out.print(" "+arr[i]);
		}
		System.out.println();
		Scanner sc = new Scanner(System.in);
		toSearchValue = sc.nextInt();
		
		
		for(i=0;i<arr.length;i++)
		{
			if(arr[i]==toSearchValue)
			{
				index=i;
				search=1;
			}
			
		}
		if(search==1)
		{
			System.out.println(index);
		}
		else
		{
			System.out.println("-1");
		}
		sc.close();
	}
}
