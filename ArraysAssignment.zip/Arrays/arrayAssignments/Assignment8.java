package arrayAssignments;

import java.util.Scanner;

public class Assignment8 {

	public static void main(String[] args) {
		
		int lis[] = new int[100]; 
	    int a = 6; 
	    int b = 7;
	    Scanner sc = new Scanner(System.in);
		System.out.print("Enter array size: ");
		int arr_size = sc.nextInt();
	    for(int i=0;i<arr_size;++i)
		{
			lis[i] = sc.nextInt();
		}
	      
	    sumexcludingrange(lis, a, b); 
	    sc.close();

	}
	static void sumexcludingrange(int li[], 
            int a, int b) 
{ 
int sum = 0; 
boolean add = true;  
for (int i = 0; i < li.length; i++) 
{ 
if (li[i] != a &&  
add == true) 
sum = sum + li[i];
else if (li[i] == a) 
add = false; 
else if( li[i] == b) 
add = true; 
} 
System.out.print(sum); 
} 

}
