package arrayAssignments;

public class Assignment4 {

	public static void main(String[] args) {
		
		char c;  
		int arr[] = {65,99,80,67,108};
		for(int i=0;i<arr.length;i++)
		{
		System.out.print(arr[i]+" ");
		}
		System.out.println();
	      for(int i=0;i<arr.length;i++) 
	      {
	         c =(char)arr[i]; 
	         System.out.print(c+" ");
	         
	      }
	      
	}

}