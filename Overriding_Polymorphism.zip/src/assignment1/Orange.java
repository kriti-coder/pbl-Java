package assignment1;

public class Orange extends Fruit {
	@Override
	public void eat () {
		System.out.println("Orange is bitter.");
	}
}
