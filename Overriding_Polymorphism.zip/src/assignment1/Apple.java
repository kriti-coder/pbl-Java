package assignment1;

public class Apple extends Fruit {
	@Override
	public void eat () {
		System.out.println("Apple is sweet.");
	}
}