module Polymorphism {
	exports assignment1;
}