module EmployeeManagementSystem {
}