package music;

public interface Playable {
	public void play();
}