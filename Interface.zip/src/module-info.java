module Inference {
}