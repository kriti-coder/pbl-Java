module VideoRentalInventorySystem {
}