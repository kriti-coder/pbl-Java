package functional_Interface;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.function.Function;
import java.util.function.Predicate;

class Employees {
    int empNo, salary;
    String name;

    Employees(int empNo, int salary, String name) {
        this.empNo = empNo;
        this.salary = salary;
        this.name = name;
    }

    @Override
    public String toString() {
        System.out.printf("Employee Details: \n Number :  %d \n Salary : %d \n Name : %s \n", empNo, salary, name);
        return "";
    }

}

public class FunInterface4 {
    public static void main(String[] args) {
        Employees emp1 = new Employees(1, 4000, "Arijit");
        Employees emp2 = new Employees(2, 24000, "Priya");
        Employees emp3 = new Employees(3, 22000, "Kriti");
        Employees emp4 = new Employees(4, 3000, "Abhinav");
        Employees emp5 = new Employees(5, 22000, "Kriti");
        ArrayList<Employees> emps = new ArrayList<>(Arrays.asList(emp1, emp2, emp3, emp4, emp5));
        Predicate<Employees> lt = emp -> emp.salary < 10000;
        emps.stream().filter(lt).forEach(System.out::print);
    }
}