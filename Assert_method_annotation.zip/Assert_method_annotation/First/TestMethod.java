package First;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

class TestMethod {
	Employee e=new Employee();
	ArrayList<String> names = new ArrayList<String>( Arrays.asList("kriti", "meets", "akriti") );
	String name="kriti";

	@Test
	void test() {
		assertEquals("FOUND", e.findName(names, name));
	}

}
