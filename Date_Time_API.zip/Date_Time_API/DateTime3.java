package Date_Time_API;

import java.time.LocalDate;
import java.time.Period;

public class DateTime3 {
    public static void main(String[] args) {
        LocalDate start = LocalDate.parse("2020-05-22");
        LocalDate now = LocalDate.now();
        Period per = Period.between(start, now);
        System.out.println("Years : " + per.getYears() + " Months : " + per.getMonths() + " Days : " + per.getDays());
    }
}