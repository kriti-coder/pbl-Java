package jUnit;

public class Demo1 {

}
