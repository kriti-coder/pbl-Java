module JavaFundamentalProject {
}