package assignmentQ2;

public class FirstClass extends Compartment{

	@Override
	public String notice(){
		return "Notice : First Compartment";
	}
}
