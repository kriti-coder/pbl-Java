package assignmentQ2;

public abstract class Compartment{

	public abstract String notice();
}
