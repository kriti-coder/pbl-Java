package assignmentQ2;

public class Luggage extends Compartment{

	@Override
	public String notice(){
		return "Notice : Luggage Compartment";
	}
}
