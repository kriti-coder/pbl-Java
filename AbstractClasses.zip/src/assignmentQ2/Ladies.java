package assignmentQ2;

public class Ladies extends Compartment{

	@Override
	public String notice(){
		return "Notice : Ladies Compartment";
	}
}
