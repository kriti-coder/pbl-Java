package assignmentQ2;

public class General extends Compartment{

	@Override
	public String notice(){
		return "Notice : General Compartment";
	}
}
