module AbstractQ1 {
}