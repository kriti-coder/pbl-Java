package assignmentQ3;

public abstract class Instrument{

	public abstract void play();
}