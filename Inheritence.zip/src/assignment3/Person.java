package assignment3;

class Person
{
	private String name;
	private String dateOfBirth;
	
	Person(String name,String dateOfBirth) {
		this.name = name;
		this.dateOfBirth=dateOfBirth;
	}

	public String getName() {
		return name;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
}	