package assignment3;

public class Assignment3 {

	public static void main(String[] args) {
		Person person=new Person("KS","22 Feb,1998");
		
		Teacher teacher=new Teacher("Hanu","1 Jan,1988",1000022,"Computer Science");
		
		Student student=new Student("KS","22 Feb,1998",67);
		
		CollegeStudent coll=new CollegeStudent("Kriti saxena","22 Feb,1998",67,4,"Dr MC saxena college");
		
		System.out.println("Person info :\nName : "+person.getName()+"\nD.O.B. : "+person.getDateOfBirth()+"\n");
		
		System.out.println("Teacher info :\nName : "+teacher.getName()+"\nD.O.B. : "+teacher.getDateOfBirth()+"\nSalary : "+teacher.getSalary()+"\nSubject : "
						  +teacher.getSubject()+"\n");
		
		System.out.println("Student info :\nName : "+student.getName()+"\nD.O.B. : "+student.getDateOfBirth()+"\nStudent Id : "+student.getStudentId()+"\n");
		
		System.out.println("College Student info :\nName : "+coll.getName()+"\nD.O.B. : "+coll.getDateOfBirth()+"\nCollege Student Id : "+coll.getStudentId()+"\nYear : "
						  +coll.getYear()+"\nCollege : "+coll.getCollegeName());
		
	}

}