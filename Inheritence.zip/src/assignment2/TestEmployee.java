package assignment2;

class TestEmployee
{
	public static void main(String[] args)
	{
		Employee e=new Employee("Kriti",350000,2020,"saxenakriti");
		System.out.println("Employee info :\nEmployee name : "+e.getName()+
		"\nAnnual Salary : "+e.getAnnualSalary()+
		"\nYear Employee Started working : "+e.getYearOfJoin()+
		"\nNational insurance NO. : "+e.getNationalInsuranceNo());
	} 
	
}	